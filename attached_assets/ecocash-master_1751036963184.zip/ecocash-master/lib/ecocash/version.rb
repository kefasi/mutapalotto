module Ecocash
  VERSION = '1.2.1'.freeze
end
